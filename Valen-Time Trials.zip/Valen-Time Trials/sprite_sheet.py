# Spritesheet class
import sys
import pygame
import random

def events():
	for event in pygame.event.get():
		if event.type == pygame.QUIT or (event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE):
			pygame.quit()
			sys.exit()
		elif event.type == pygame.KEYDOWN and event.key ==pygame.K_SPACE:
			break

class Spritesheet():
	def __init__(self,filename,columns,rows,x_scale,y_scale,key_handle,frames):
	
		self.sheet_raw = pygame.image.load(filename)#.convert_alpha()
		self.sheet = pygame.transform.scale(self.sheet_raw,(x_scale,y_scale))
		self.col = columns
		self.rows = rows
		self.cell_count = columns*rows
		self.key_handle = key_handle
		self.index = 0
		self.frames = frames

		self.rect = self.sheet.get_rect()
		w = self.cell_width = self.rect.width/columns
		h = self.cell_height = self.rect.height/rows
		hw, hh = self.cell_center = w/2, h/2

		self.cells = list([(index % self.col * w, index // self.col * h, w, h) for index in range(self.cell_count)])

		self.handle = list([
			(0, 0), (-hw, 0), (-w, 0),
			(0, -hh), (-hw, -hh), (-w, -hh),
			(0, -h), (-hw, -h), (-w, -h),])
		
	def draw(self, surface, x, y, frame, framespeed, handle = 0):
		cellIndex = self.index % self.cell_count
		surface.blit(self.sheet, (x + self.handle[handle][0], y + self.handle[handle][1]), self.cells[cellIndex])
		if frame % framespeed == 0 and self.index+1 < self.frames:
			self.index += 1
		elif frame % 5 == 0 and self.index+1 >= self.frames:
			self.index = 0


	def check_index(self):
		for i in range(self.cell_count):
			print("[{0}] -> ".format(i), (str(i%self.col*self.cell_width), str(i//self.col*self.cell_height)))
