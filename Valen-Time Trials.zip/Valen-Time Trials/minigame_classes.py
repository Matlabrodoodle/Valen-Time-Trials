# This script contains the three functions with the three mini-games
import pygame, os, sys, random, numpy as np
from PIL import Image
from sprite_sheet import*

# Image identification game
def image_id(player):
	# Initialize pygame assets
	pygame.init()
	pygame.mouse.set_visible(False)
	pygame.display.set_caption("Romantic Imagery")
	pygame.mixer.init()
	pygame.mixer.music.load('Val Photo cut.ogg')

	clock = pygame.time.Clock()
	screen_size = (1500, 750)
	backscreen = pygame.display.set_mode(screen_size)
	backscreen.fill((250,250,250))#((255,102,178))
	correct_guess = False
	number_correct = 0

	# Instructions loop
	textframe = pygame.transform.scale(pygame.image.load('instructions_frame.png'), screen_size)
	instructions = True
	inst_font = pygame.font.SysFont('comicsans',40)
	message = "Type what you see in the image and hit enter!"
	continue_message = "Press Space to Begin"
	inst_text = inst_font.render(message, True, (0,0,0))
	continue_text = inst_font.render(continue_message,True,(0,0,0))

	while instructions:
		backscreen.fill((250,250,250))
		backscreen.blit(textframe,(0,0))
		backscreen.blit(inst_text, (380,250))
		backscreen.blit(continue_text, (380,500))

		for event in pygame.event.get():
			if event.type == pygame.QUIT or (event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE):
				player.running = False
				pygame.quit()
				sys.exit()
			if event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
				instructions = False
		pygame.display.update()

	# Download images and descriptions
	image_01 = Image.open("Bouquet of Roses 1.jpg")
	image_02 = Image.open("Bouquet of Roses 2.jpg")
	image_03 = Image.open("Bouquet of Roses 3.jpg")

	image_04 = Image.open("Box of Chocolates 1.jpg")
	image_05 = Image.open("Box of Chocolates 3.jpg")
	image_06 = Image.open("Box of Chocolates 4.jpg")

	image_07 = Image.open("Card 2.jpg")
	image_08 = Image.open("Card 3.jpg")

	image_09 = Image.open("Champagne 1.jpg")
	image_10 = Image.open("Champagne 2.jpg")
	image_11 = Image.open("Champagne 4.jpg")

	image_12 = Image.open("Cupid Cherub 2.jpg")
	image_13 = Image.open("Cupid Cherub 3.jpg")

	image_14 = Image.open("Gift 1.jpg")
	image_15 = Image.open("Gift 2.jpg")
	image_16 = Image.open("Gift 3.jpg")

	image_17 = Image.open("Heart Cookies 1.jpg")
	image_18 = Image.open("Heart Cookies 2.jpg")
	image_19 = Image.open("Heart Cookies 3.jpg")

	image_20 = Image.open("Scented Candles 1.jpg")
	image_21 = Image.open("Scented Candles 2.jpg")
	image_22 = Image.open("Scented Candles 3.jpg")

	# List possible responses (because I hate regexes)
	response_01 = ["flower","flowers","rose","roses","bouquet","flower bouquet","vase of roses","basket of roses","pot of flowers","flower pot"
	, "flower pots"]
	response_02 = response_01 
	response_03 = response_01 
	response_04 = ["box of chocolates","chocolate","chocolates","box of chocolate"]
	response_05 = response_04
	response_06 = response_04
	response_07 = ["card","valentine's card", "cards","valetines card","valentine's cards","valentine's day card","valentine's day cards", 
	"valentines day card", "valentines day cards","letter","kiss","letters","note","notes"]
	response_08 = response_07
	response_08.append("lips")
	response_09 = ["champagne","sparkling wine","white wine","red wine","wine"]
	response_10 = response_09
	response_11 = response_10
	response_12 = ["cupid","cherub","cherubs","angel","baby cupid","baby angel","cupid's bow"]
	response_13 = response_12
	response_14 = ["gift","gifts","present","presents"]
	response_15 = response_14	
	response_16 = response_14	
	response_17 = ["heart cookie","cookie","cookies","heart cookies","valentine's cookie","valentine's cookies","sugar cookie","sugar cookies",
	"frosted cookie","frosted cookies","heart-shaped cookie","heart shaped cookies"]
	response_18 = response_17
	response_19 = response_17
	response_20 = ["candle","candles","scented candle","scented candles","heart candle","mood candle","wax candle","dinner candle","dinner candles"
	"wax candles","heart candles"]
	response_21 = response_20
	response_22 = response_20

	# Place images and descriptions in list
	image_list = [image_01, image_02, image_03, image_04, image_05,image_06,image_07,image_08,image_09,image_10,image_11,image_12,image_13,image_14,
	image_15, image_16,image_17,image_18,image_19,image_20,image_21,image_22]
	response_list = [response_01,response_02,response_03,response_04,response_05,response_06,response_07,response_08,response_09,response_10,response_11,
	response_12,response_13,response_14,response_15,response_16,response_17,response_18,response_19,response_20,response_21,response_22]

	timer = 30*20
	timerbox = pygame.Rect(20,20,210,40)
	input_box = pygame.Rect(650, 650, 140, 32)
	textbox = pygame.transform.scale(pygame.image.load('bubble.png'), (300,50))
	usertext = ''
	font = pygame.font.SysFont('comicsans',30)

	# Create indexing system for pixels in images
	backscreen.fill((250,250,250))
	active_index = random.randrange(0,len(image_list))
	active_image = image_list[active_index]
	active_response = response_list[active_index]
	active_image = active_image.resize(screen_size,Image.ANTIALIAS)
	width, height = active_image.size
	pixel_index = np.ones((width, height))

	# Play music
	pygame.mixer.music.play(loops=-1)

	# Main loop
	while True:
		clock.tick(30)

		# Track correct guesses and remove guessed images (no repeats)
		if correct_guess:
			if len(image_list) == 1:
				break
			number_correct += 1
			correct_guess = False
			backscreen.fill((250,250,250))
			del image_list[active_index]
			del response_list[active_index]
			active_index = random.randrange(0,len(image_list))
			active_image = image_list[active_index]
			active_response = response_list[active_index]
			active_image = active_image.resize(screen_size,Image.ANTIALIAS)
			width, height = active_image.size
			pixel_index = np.ones((width, height))

		if timer%3 == 0:
			reveal = 20000
			if 0 < np.count_nonzero(pixel_index == 1) < 100000:
				for x in range(width):
					for y in range(height):
						if pixel_index[x,y] == 1:
							pixel_color = active_image.getpixel((x,y))
							pixel_index[x,y] = 0
							backscreen.set_at((x, y), pixel_color)
			elif np.count_nonzero(pixel_index == 1)  == 0:
				pass
			else:
				for i in range(1,reveal):		
					x = random.randrange(0,width)
					y = random.randrange(0,height)
					if pixel_index[x,y] == 1:
					
						pixel_color = active_image.getpixel((x,y))
						pixel_index[x,y] = 0
						backscreen.set_at((x, y), pixel_color)
		
		# Let user guess at image
		for event in pygame.event.get():
		
			if event.type == pygame.QUIT or (event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE):
				player.running = False
				pygame.quit()
				sys.exit()

			elif event.type == pygame.KEYDOWN:
				if event.key == pygame.K_RETURN:
					if usertext.lower() in active_response:
						correct_guess = True
					else:
						pass
						
					usertext = ''
				elif event.key == pygame.K_BACKSPACE:
					usertext = usertext[:-1]
				else:
					usertext += event.unicode

		txt_surface = font.render(usertext, True, (255,255,255))
		boxwidth = max(120, txt_surface.get_width()+10)
		input_box.w = boxwidth
		
		# Update on-screen timer
		if timer%30 == 0:
			text = font.render("Time remaining: " + str(int(timer/30)) ,1, (0,0,0))
		
		# Draw everything and update screen
		pygame.draw.rect(backscreen,(255,153,204),timerbox)
		pygame.draw.rect(backscreen,(255,153,153),input_box)
		backscreen.blit(textbox,(600,640))
		backscreen.blit(text,(30,30))
		backscreen.blit(txt_surface, (input_box.x+5, input_box.y+5))

		pygame.display.update()

		timer -= 1
		if timer == 0:
			break 

	# Calculate points and update player class
	player.points_01 = number_correct*20
	pygame.quit()

# Button-mashing game function
def button_masher(player):
	# Initialize Pygame assets
	pygame.init()
	pygame.mouse.set_visible(False)
	pygame.display.set_caption("Flower Run")
	pygame.mixer.init()
	pygame.mixer.music.load('Val Mash.ogg')
	clock = pygame.time.Clock()
	screen_size = (1500, 750)
	backscreen = pygame.display.set_mode(screen_size)
	backscreen.fill((0,0,0))

	# Create list of possible key values
	key_choices = ["v","l","n","t","s","d","y"]
	timer = 30*30
	distance = 0
	active_key = random.choice(key_choices)
	key_width = 200
	key_height = 200
	key_speed = 7

	# Import character and background images
	background = pygame.transform.scale(pygame.image.load('Run Game Background.png'), screen_size)
	hero = pygame.transform.scale(pygame.image.load('the Hero.png'), (100,100))

	# Create spritesheet objects for animations
	v = Spritesheet('V key.png',2,2,key_width,key_height,1,key_speed)
	l = Spritesheet('L key.png',2,2,key_width,key_height,1,key_speed)
	n = Spritesheet('N key.png',2,2,key_width,key_height,1,key_speed)
	t = Spritesheet('T key.png',2,2,key_width,key_height,1,key_speed)
	s = Spritesheet('S key.png',2,2,key_width,key_height,1,key_speed)
	d = Spritesheet('D key.png',2,2,key_width,key_height,1,key_speed)
	y = Spritesheet('Y key.png',2,2,key_width,key_height,1,key_speed)

	# Instructions loop
	textframe = pygame.transform.scale(pygame.image.load('instructions_frame.png'), screen_size)
	instructions = True
	inst_font = pygame.font.SysFont('comicsans',40)
	message = "Mash the key shown on screen to run flowers to your love!"
	continue_message = "Press Space to Begin"
	inst_text = inst_font.render(message, True, (0,0,0))
	continue_text = inst_font.render(continue_message,True,(0,0,0))

	while instructions:
		backscreen.fill((250,250,250))
		backscreen.blit(textframe,(0,0))
		backscreen.blit(inst_text, (380,250))
		backscreen.blit(continue_text, (380,500))

		for event in pygame.event.get():
			if event.type == pygame.QUIT or (event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE):
				player.running = False
				pygame.quit()
				sys.exit()
			if event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
				instructions = False
		pygame.display.update()

	frame = 1
	pygame.mixer.music.play(loops=-1)
	# Main loop
	while True:
		clock.tick(30)
		for event in pygame.event.get():
		
			if event.type == pygame.QUIT or (event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE):
				player.running = False
				pygame.quit()
				sys.exit()

			elif event.type == pygame.KEYDOWN:
				# Move on-screen character when correct key is hit
				if pygame.key.name(event.key) == active_key:
					distance += 5
				# Penalize random mashing
				else:
					if distance > 0:
						distance -= 1

		# Switch active key every three seconds
		if timer%90 == 0:
			# Use a random choice to choose what letter is mashed
			active_key = random.choice([i for i in key_choices if i != active_key])
			if active_key == "v":
				pushkey = v
			elif active_key == "l":
				pushkey = l
			elif active_key == "t":
				pushkey = t  
			elif active_key == "n":
				pushkey = n 
			elif active_key == "d":
				pushkey = d
			elif active_key == "y":
				pushkey = y
			elif active_key == "s":
				pushkey = s

		# Fill screen and draw everything
		backscreen.fill((255,153,204))
		backscreen.blit(background,(0,0))
		backscreen.blit(hero,(distance*2+130,280))
		pushkey.draw(backscreen,700,566,frame,1)	
		pygame.display.update()
		
		# Iterate through frames
		if frame <= 4:
			frame+=1
		else: 
			frame = 1
		timer -= 1

		# End game once one of these conditions is met
		if distance >= 500 or timer > 900:
			break

	# Point allocation based on remaining time
	if 350 < timer: 
		points = 300
	elif 250 < timer <= 350:
		points = 200
	elif 150 < timer <= 250:
		points = 150
	elif 50 < timer <= 150:
		points = 100
	elif 0 < timer <= 50:
		points = 50
	else:
		points = 0 

	print(str(points))
	player.points_02 = points 
	print(timer)
	pygame.quit()

# Sorting letters game functions
def sorting_game(player):
	# Initialize Pygame assets
	pygame.init()
	pygame.mouse.set_visible(True)
	pygame.display.set_caption("Delivery Frenzy")
	pygame.mixer.init()
	pygame.mixer.music.load('Val Maze cut.ogg')
	clock = pygame.time.Clock()
	screen_size = (1500, 750)
	backscreen = pygame.display.set_mode(screen_size)
	backscreen.fill((0,0,0))
	background = pygame.transform.scale(pygame.image.load('sorting_background.png'), screen_size)
	
	timer = 30*30

	# Create player class to track mouse actions
	class Player():
		def __init__(self):
			self.holding = False
			self.occupied = False

	# Create mail/letter class and inherit from Sprite
	class Mail(pygame.sprite.Sprite):
		def __init__(self,x,y,width,height,filename,screen,color):
			super(Mail,self).__init__()
			self.x = x
			self.y = y
			self.width = width
			self.height = height
			self.active = True
			self.screen = screen
			self.color = color
			self.filename = filename
			self.image = pygame.transform.scale(pygame.image.load(filename), (width,height))
			self.rect = pygame.Rect(self.x,self.y,self.width,self.height)
			self.hitbox = pygame.Rect(self.x+20,self.y+20,self.width/1.5-10,self.height/1.5+10)
			self.held = False

		# Move mail if picked up by player
		def update(self,person):
			self.rect = pygame.Rect(self.x,self.y,self.width,self.height)
			self.hitbox = pygame.Rect(self.x+20,self.y+20,self.width/1.5-10,self.height/1.5+10)
			
			if person.holding and not person.occupied:
				self.mx, self.my = pygame.mouse.get_pos()
				if self.hitbox.collidepoint(self.mx,self.my):
					self.held = True
					person.occupied = True
			
			elif not person.holding:
				self.held = False

			if self.held:
				self.mx, self.my = pygame.mouse.get_pos()
				self.x = self.mx-self.width/2
				self.y = self.my-self.height/2

		# Draw mail to screen
		def draw(self):
			if self.active:
				# pygame.draw.rect(self.screen,(255,255,0),self.rect)
				# pygame.draw.rect(self.screen,(255,0,255),self.hitbox)
				self.screen.blit(self.image,self.rect)

	# Similarly use mailbox class to detect collisions etc.
	class Mailbox(pygame.sprite.Sprite):
		def __init__(self,x,y,width,height,filename,screen,color):
			super(Mailbox,self).__init__()
			self.x = x
			self.y = y
			self.width = width
			self.height = height
			self.screen = screen
			self.color = color
			self.filename = filename
			self.image = pygame.transform.scale(pygame.image.load(filename), (width,height))
			self.rect = pygame.Rect(self.x,self.y,self.width,self.height)
			self.hitbox = pygame.Rect(self.x+10,self.y,self.width/2,self.height/4)

		def update(self,mailgroup):
			self.hitbox = pygame.Rect(self.x+40,self.y+30,self.width/2,self.height/3+10)
			self.rect = pygame.Rect(self.x,self.y,self.width,self.height)
		def draw(self):
			# pygame.draw.rect(self.screen,(255,255,0),self.rect)
			# pygame.draw.rect(self.screen,(255,0,255),self.hitbox)
			self.screen.blit(self.image,self.rect)

	# Add mail and mailboxes to their respesctive groups 
	mailboxes = pygame.sprite.Group()
	mailgroup = pygame.sprite.Group()
	mailcount = 5

	mail_filenames = ["red_mail.png","green_mail.png","blue_mail.png"]
	possible_colors = ["r","g","b"]

	mailbox_y_pos = 100
	mailbox_width = 150
	mailbox_height = 150

	# Create three instances of mailbox
	red_mailbox = Mailbox(150,mailbox_y_pos,mailbox_width,mailbox_height,"red_mailbox.png",backscreen,"r")
	green_mailbox = Mailbox(650,mailbox_y_pos,mailbox_width,mailbox_height,"green_mailbox.png",backscreen,"g")
	blue_mailbox = Mailbox(1150,mailbox_y_pos,mailbox_width,mailbox_height,"blue_mailbox.png",backscreen,"b")

	mailboxes.add(red_mailbox, green_mailbox, blue_mailbox)
	mail_sent = 0

	font = pygame.font.SysFont('comicsans',30)
	textframe = pygame.transform.scale(pygame.image.load('instructions_frame.png'), screen_size)
	instructions = True
	inst_font = pygame.font.SysFont('comicsans',40)
	message = "Use your mouse to click and drag Valentine's letters to "
	message_2 = "their color-corresponding mailboxes!"
	continue_message = "Press Space to Begin"
	inst_text = inst_font.render(message, True, (0,0,0))
	inst_text_2 = inst_font.render(message_2, True, (0,0,0))
	continue_text = inst_font.render(continue_message,True,(0,0,0))

	person = Player()

	# Show instructions
	while instructions:
		backscreen.fill((250,250,250))
		backscreen.blit(textframe,(0,0))
		backscreen.blit(inst_text, (380,250))
		backscreen.blit(inst_text_2, (380,290))
		backscreen.blit(continue_text, (380,500))

		for event in pygame.event.get():
			if event.type == pygame.QUIT or (event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE):
				player.running = False
				pygame.quit()
				sys.exit()
			if event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
				instructions = False
		pygame.display.update()

	# Start main loop
	pygame.mixer.music.play(loops=-1)
	while True:
		clock.tick(30)

		# Use random choice to pick what color mail spawns, up to the number specified by mailcount
		if len(mailgroup) < mailcount and timer%30==0:
			color = random.choice(possible_colors)
			if color == "r":
				filename = mail_filenames[0]
			elif color == "g":
				filename = mail_filenames[1]
			else:
				filename = mail_filenames[2]

		# Randomly place letter on screen
			x = random.randrange(10,screen_size[0]-80)
			y = random.randrange(300,650)
			new_mail = Mail(x,y,100,100,filename,backscreen,color)
			mailgroup.add(new_mail)

		# Check events
		for event in pygame.event.get():
			if event.type == pygame.QUIT or (event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE):
				player.running = False
				pygame.quit()
				sys.exit()

			elif event.type == pygame.MOUSEBUTTONDOWN:
				if event.button == 1:
					person.holding = True
			
			elif event.type == pygame.MOUSEBUTTONUP:
				if event.button == 1:
					person.holding = False
					person.occupied = False

		backscreen.fill((255,102,176))
		backscreen.blit(background,(0,0))

		for box in mailboxes:
			box.update(mailgroup)
			box.draw()

		for mail in mailgroup:
			if mail.color == "r":
				if mail.hitbox.colliderect(red_mailbox.hitbox):
					mail.active = False
					mail_sent += 1
					mailgroup.remove(mail)

			elif mail.color == "g":
				if mail.hitbox.colliderect(green_mailbox.hitbox):
					mail.active = False
					mail_sent += 1
					mailgroup.remove(mail)

			elif mail.color == "b":
				if mail.hitbox.colliderect(blue_mailbox.hitbox):
					mail.active = False
					mail_sent += 1
					mailgroup.remove(mail)

			if mail.active == True:
				mail.update(person)
				mail.draw()

		# Display countdown
		text = font.render("Time remaining: " + str(int(timer/30)) ,1, (0,0,0))
		backscreen.blit(text,(30,30))

		pygame.display.update()
		timer -= 1

		if timer == 0:
			break

	# Calculate points and send to player/gamestats class
	player.points_03 = mail_sent*10
	pygame.quit()

